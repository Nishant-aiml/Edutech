import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { AuthUser } from '../services/auth';
import { register, login, logout, validateSession } from '../services/auth';
import { initializeDatabase } from '../services/database';

interface AuthContextType {
  isAuthenticated: boolean;
  user: AuthUser | null;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  register: (credentials: {
    name: string;
    email: string;
    password: string;
    role: string;
    language?: string;
  }) => Promise<void>;
  logout: () => void;
  isEducator: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isEducator, setIsEducator] = useState(false);

  useEffect(() => {
    // Initialize database on mount
    initializeDatabase().catch(console.error);

    // Check for existing session
    const token = localStorage.getItem('token');
    if (token) {
      validateSession(token)
        .then((session) => {
          if (session) {
            setIsAuthenticated(true);
            setUser(session.user);
            setIsEducator(session.user.role === 'educator');
          } else {
            localStorage.removeItem('token');
          }
        })
        .catch(console.error);
    }
  }, []);

  const handleLogin = async (credentials: { email: string; password: string }) => {
    const { token, user } = await login(credentials);
    localStorage.setItem('token', token);
    setIsAuthenticated(true);
    setUser(user);
    setIsEducator(user.role === 'educator');
  };

  const handleRegister = async (credentials: {
    name: string;
    email: string;
    password: string;
    role: string;
    language?: string;
  }) => {
    const { token, user } = await register(credentials);
    localStorage.setItem('token', token);
    setIsAuthenticated(true);
    setUser(user);
    setIsEducator(user.role === 'educator');
  };

  const handleLogout = async () => {
    const token = localStorage.getItem('token');
    if (token) {
      await logout(token);
      localStorage.removeItem('token');
    }
    setIsAuthenticated(false);
    setUser(null);
    setIsEducator(false);
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        user,
        login: handleLogin,
        register: handleRegister,
        logout: handleLogout,
        isEducator
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}