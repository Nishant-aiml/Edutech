import { Filter } from 'lucide-react';

interface CourseFiltersProps {
  selectedCategory: string;
  selectedLevel: string;
  selectedDuration: string;
  showFilters: boolean;
  setShowFilters: (show: boolean) => void;
  setSelectedCategory: (category: string) => void;
  setSelectedLevel: (level: string) => void;
  setSelectedDuration: (duration: string) => void;
}

const CATEGORIES = ['All', 'Development', 'Business', 'Design', 'Marketing', 'Data Science'];
const LEVELS = ['All Levels', 'Beginner', 'Intermediate', 'Advanced'];
const DURATIONS = ['All Durations', '0-5 hours', '5-10 hours', '10+ hours'];

export default function CourseFilters({
  selectedCategory,
  selectedLevel,
  selectedDuration,
  showFilters,
  setShowFilters,
  setSelectedCategory,
  setSelectedLevel,
  setSelectedDuration
}: CourseFiltersProps) {
  return (
    <>
      <button
        onClick={() => setShowFilters(!showFilters)}
        className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
      >
        <Filter className="h-5 w-5" />
        Filters
      </button>

      {showFilters && (
        <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                {CATEGORIES.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Level</label>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                {LEVELS.map(level => (
                  <option key={level} value={level}>{level}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Duration</label>
              <select
                value={selectedDuration}
                onChange={(e) => setSelectedDuration(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                {DURATIONS.map(duration => (
                  <option key={duration} value={duration}>{duration}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}
    </>
  );
}