import { useState } from 'react';
import CourseCard from './CourseCard';
import type { Course } from '../types';

const CATEGORIES = ['All', 'Development', 'Business', 'Design', 'Marketing'];

const SAMPLE_COURSES: Course[] = [
  {
    id: '1',
    title: 'Complete Web Development Bootcamp',
    description: 'Master HTML, CSS, JavaScript, React, and Node.js in this comprehensive course.',
    instructor: 'Sarah Johnson',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
    category: 'Development',
    level: 'Beginner',
    duration: '40 hours',
    rating: 4.8,
    enrolled: 15420
  },
  {
    id: '2',
    title: 'Digital Marketing Masterclass',
    description: 'Learn SEO, social media marketing, and content strategy from industry experts.',
    instructor: 'Michael Chen',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
    category: 'Marketing',
    level: 'Intermediate',
    duration: '25 hours',
    rating: 4.7,
    enrolled: 8930
  },
  {
    id: '3',
    title: 'UI/UX Design Fundamentals',
    description: 'Create stunning user interfaces and improve user experience with modern design principles.',
    instructor: 'Emma Davis',
    thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5',
    category: 'Design',
    level: 'Beginner',
    duration: '30 hours',
    rating: 4.9,
    enrolled: 12340
  }
];

export default function PopularCourses() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredCourses = SAMPLE_COURSES.filter(
    course => selectedCategory === 'All' || course.category === selectedCategory
  );

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Popular Courses</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore our most popular courses and start your learning journey today
          </p>
        </div>

        <div className="flex justify-center mb-8 space-x-4">
          {CATEGORIES.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                ${selectedCategory === category
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map(course => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors">
            View All Courses
          </button>
        </div>
      </div>
    </section>
  );
}