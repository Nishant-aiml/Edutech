import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Free',
    price: '₹0',
    description: 'Perfect for getting started',
    features: [
      'Access to free courses',
      'Basic community features',
      'Limited course materials',
      'Mobile app access'
    ]
  },
  {
    name: 'Pro',
    price: '₹999',
    period: '/month',
    description: 'Most popular for individuals',
    features: [
      'All free features',
      'Unlimited course access',
      'Certification programs',
      'Priority support',
      'Mentor consultation',
      'Career guidance'
    ],
    featured: true
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    description: 'For organizations & teams',
    features: [
      'All Pro features',
      'Custom learning paths',
      'Dedicated support',
      'Analytics dashboard',
      'API access',
      'Bulk enrollment'
    ]
  }
];

export default function Pricing() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Affordable Plans for Everyone</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose the perfect plan that fits your learning needs and budget
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`bg-white rounded-xl shadow-md overflow-hidden ${
                plan.featured ? 'ring-2 ring-indigo-600' : ''
              }`}
            >
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                  {plan.period && (
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  )}
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <button
                  className={`w-full py-3 px-4 rounded-lg font-medium ${
                    plan.featured
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  } transition-colors`}
                >
                  Get Started
                </button>
              </div>
              <div className="px-8 pb-8">
                <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wide mb-4">
                  What's included
                </h4>
                <ul className="space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}