import { Calendar, Clock, MapPin } from 'lucide-react';

interface EventCardProps {
  event: {
    title: string;
    date: string;
    time: string;
    location: string;
    description: string;
  };
}

export default function EventCard({ event }: EventCardProps) {
  const formattedDate = new Date(event.date).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">{event.title}</h3>
      
      <div className="space-y-3 mb-4">
        <div className="flex items-center text-gray-600">
          <Calendar className="h-5 w-5 mr-2" />
          {formattedDate}
        </div>
        <div className="flex items-center text-gray-600">
          <Clock className="h-5 w-5 mr-2" />
          {event.time}
        </div>
        <div className="flex items-center text-gray-600">
          <MapPin className="h-5 w-5 mr-2" />
          {event.location}
        </div>
      </div>
      
      <p className="text-gray-600 mb-4">{event.description}</p>
      
      <button className="w-full py-2 px-4 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
        Register Now
      </button>
    </div>
  );
}