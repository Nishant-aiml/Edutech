import { Users, BookOpen, Award, Building } from 'lucide-react';

const stats = [
  {
    icon: Users,
    value: '100,000+',
    label: 'Active Learners'
  },
  {
    icon: BookOpen,
    value: '1,000+',
    label: 'Expert-Led Courses'
  },
  {
    icon: Award,
    value: '50,000+',
    label: 'Certifications Awarded'
  },
  {
    icon: Building,
    value: '200+',
    label: 'Corporate Partners'
  }
];

export default function Stats() {
  return (
    <section className="py-16 bg-indigo-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-white/10 rounded-lg mb-4">
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-indigo-100">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}