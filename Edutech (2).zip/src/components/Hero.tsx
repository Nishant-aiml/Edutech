import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-32">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1523240795612-9a054b0db644"
          alt="Students studying"
          className="w-full h-full object-cover opacity-20"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Start Your Learning Journey Today
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Join our community of learners and transform your future with expert-led courses
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/enroll"
              className="inline-flex items-center px-8 py-4 bg-white text-indigo-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition-colors"
            >
              Enroll Now
              <ArrowRight className="ml-2 h-6 w-6" />
            </Link>
            <Link
              to="/courses"
              className="inline-flex items-center px-8 py-4 bg-transparent border-2 border-white rounded-lg font-bold text-lg hover:bg-white hover:text-indigo-600 transition-colors"
            >
              Browse Courses
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}