interface TestimonialFiltersProps {
  selectedCourse: string;
  setSelectedCourse: (course: string) => void;
  selectedRating: number | null;
  setSelectedRating: (rating: number | null) => void;
}

const COURSES = ['All Courses', 'Web Development', 'Data Science', 'UI/UX Design', 'Digital Marketing'];

export default function TestimonialFilters({
  selectedCourse,
  setSelectedCourse,
  selectedRating,
  setSelectedRating
}: TestimonialFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-4 mb-8">
      <div className="flex-1">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Filter by Course
        </label>
        <select
          value={selectedCourse}
          onChange={(e) => setSelectedCourse(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded-lg"
        >
          {COURSES.map(course => (
            <option key={course} value={course}>{course}</option>
          ))}
        </select>
      </div>
      <div className="flex-1">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Filter by Rating
        </label>
        <select
          value={selectedRating || ''}
          onChange={(e) => setSelectedRating(e.target.value ? Number(e.target.value) : null)}
          className="w-full p-2 border border-gray-300 rounded-lg"
        >
          <option value="">All Ratings</option>
          <option value="5">5 Stars</option>
          <option value="4">4+ Stars</option>
          <option value="3">3+ Stars</option>
        </select>
      </div>
    </div>
  );
}