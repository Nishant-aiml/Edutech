import { Menu, Search, Bell, LogOut } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const NAVIGATION = [
  { name: 'Start Learning', href: '/learn', requiresAuth: true },
  { name: 'Community', href: '/community', requiresAuth: true },
  { name: 'Resources', href: '/resources', requiresAuth: true },
  { name: 'Become an Instructor', href: '/teach', requiresAuth: true }
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-white shadow-lg fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <button 
              className="p-2 rounded-md lg:hidden"
              onClick={() => setIsOpen(!isOpen)}
            >
              <Menu className="h-6 w-6 text-gray-600" />
            </button>
            <Link to="/" className="flex-shrink-0 flex items-center ml-4">
              <h1 className="text-2xl font-bold text-indigo-600">EduHub</h1>
            </Link>
            {isAuthenticated && (
              <div className="hidden lg:flex lg:items-center lg:ml-6 space-x-4">
                {NAVIGATION.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`px-3 py-2 rounded-md text-sm font-medium ${
                      location.pathname === item.href
                        ? 'text-indigo-600'
                        : 'text-gray-700 hover:text-indigo-600'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex items-center">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <div className="hidden md:block">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search courses..."
                      className="w-64 pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-indigo-500"
                    />
                    <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                </div>
                <Link to="/profile" className="flex items-center">
                  <img
                    src={user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || '')}&background=random`}
                    alt={user?.name}
                    className="h-8 w-8 rounded-full"
                  />
                </Link>
                <button className="text-gray-600 hover:text-indigo-600">
                  <Bell className="h-6 w-6" />
                </button>
                <button 
                  onClick={handleLogout}
                  className="text-gray-600 hover:text-indigo-600"
                >
                  <LogOut className="h-6 w-6" />
                </button>
              </div>
            ) : (
              location.pathname !== '/get-started' && (
                <Link
                  to="/get-started"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Get Started
                </Link>
              )
            )}
          </div>
        </div>
      </div>

      {isOpen && isAuthenticated && (
        <div className="lg:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {NAVIGATION.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  location.pathname === item.href
                    ? 'text-indigo-600 bg-indigo-50'
                    : 'text-gray-700 hover:text-indigo-600 hover:bg-gray-50'
                }`}
                onClick={() => setIsOpen(false)}
              >
                {item.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}