import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { getChatRooms, type ChatRoom } from '../../services/chat';
import { formatDistanceToNow } from 'date-fns';

interface ChatListProps {
  onSelectChat: (chatRoom: ChatRoom) => void;
  selectedChatId?: number;
}

export default function ChatList({ onSelectChat, selectedChatId }: ChatListProps) {
  const { user } = useAuth();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);

  useEffect(() => {
    if (user) {
      const rooms = getChatRooms(user.id);
      setChatRooms(rooms);
    }
  }, [user]);

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Messages</h2>
      </div>
      <div className="divide-y divide-gray-200">
        {chatRooms.map((room) => {
          const isStudent = user?.role === 'student';
          const otherName = isStudent ? room.educator_name : room.student_name;
          
          return (
            <button
              key={room.id}
              onClick={() => onSelectChat(room)}
              className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                selectedChatId === room.id ? 'bg-indigo-50' : ''
              }`}
            >
              <div className="flex items-start space-x-3">
                <img
                  src={`https://ui-avatars.com/api/?name=${encodeURIComponent(otherName)}&background=random`}
                  alt={otherName}
                  className="w-10 h-10 rounded-full"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{otherName}</p>
                  {room.last_message && (
                    <>
                      <p className="text-sm text-gray-600 truncate">
                        {room.last_message.content}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(room.last_message.created_at), { addSuffix: true })}
                      </p>
                    </>
                  )}
                </div>
              </div>
            </button>
          );
        })}
        {chatRooms.length === 0 && (
          <div className="p-4 text-center text-gray-500">
            No messages yet
          </div>
        )}
      </div>
    </div>
  );
}