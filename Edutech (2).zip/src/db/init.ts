import { createClient } from '@libsql/client';

const db = createClient({
  url: 'file:local.db',
});

// Enable foreign key support
async function enableForeignKeys() {
  await db.execute('PRAGMA foreign_keys = ON');
}

// Create users table
async function createUsersTable() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('student', 'educator', 'admin')),
      avatar TEXT,
      language TEXT DEFAULT 'en',
      subscription_tier TEXT DEFAULT 'free',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
}

// Create chat_rooms table
async function createChatRoomsTable() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS chat_rooms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL,
      educator_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES users(id),
      FOREIGN KEY (educator_id) REFERENCES users(id),
      UNIQUE(student_id, educator_id)
    )
  `);
}

// Create messages table
async function createMessagesTable() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_room_id INTEGER NOT NULL,
      sender_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      read_at DATETIME,
      FOREIGN KEY (chat_room_id) REFERENCES chat_rooms(id),
      FOREIGN KEY (sender_id) REFERENCES users(id)
    )
  `);
}

// Initialize database
async function initializeDatabase() {
  await enableForeignKeys();
  await createUsersTable();
  await createChatRoomsTable();
  await createMessagesTable();
}

export { db, initializeDatabase };