export interface User {
  id: string;
  name: string;
  role: 'student' | 'educator' | 'admin';
  avatar: string;
  language: string;
  subscriptionTier: 'free' | 'basic' | 'premium' | 'enterprise';
  email?: string;
  phone?: string;
  subjects?: string[];
  badges?: Badge[];
  mentorId?: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  thumbnail: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  rating: number;
  enrolled: number;
  language: string;
  price: number;
  features: string[];
  chapters: Chapter[];
  isLive?: boolean;
  nextLiveSession?: string;
}

export interface Chapter {
  id: string;
  title: string;
  duration: string;
  videoUrl?: string;
  resources: Resource[];
  quiz?: Quiz;
}

export interface Resource {
  id: string;
  title: string;
  type: 'pdf' | 'video' | 'audio' | 'link';
  url: string;
  isDownloadable: boolean;
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
  timeLimit: number;
  passingScore: number;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  earnedAt: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  discountedPrice?: number;
  category: string;
  image: string;
  stock: number;
  rating: number;
  reviews: number;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  createdAt: string;
  shippingAddress: Address;
}

export interface Address {
  street: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}

export interface LiveSession {
  id: string;
  courseId: string;
  title: string;
  description: string;
  startTime: string;
  duration: number;
  instructor: string;
  attendees: number;
  isActive: boolean;
}

export interface ForumPost {
  id: string;
  userId: string;
  title: string;
  content: string;
  tags: string[];
  likes: number;
  replies: number;
  createdAt: string;
}

export interface Analytics {
  totalStudents: number;
  activeStudents: number;
  completionRate: number;
  averageScore: number;
  popularCourses: {
    courseId: string;
    enrollments: number;
  }[];
  recentActivity: {
    type: 'enrollment' | 'completion' | 'quiz';
    courseId: string;
    userId: string;
    timestamp: string;
  }[];
}