import { useLocation, useNavigate, Link } from 'react-router-dom';
import { CheckCircle, ArrowLeft, Calendar, Clock } from 'lucide-react';

export default function EnrollmentConfirmation() {
  const location = useLocation();
  const navigate = useNavigate();
  const { formData } = location.state || {};

  if (!formData) {
    return (
      <div className="min-h-screen bg-gray-50 pt-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Invalid Enrollment</h1>
            <p className="text-gray-600 mb-8">No enrollment data found.</p>
            <Link
              to="/enroll"
              className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Return to Enrollment Form
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={() => navigate('/')}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-8"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </button>

        <div className="bg-white rounded-xl shadow-sm p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Enrollment Successful!</h1>
            <p className="text-lg text-gray-600">
              Thank you for enrolling. We've sent the confirmation details to your email.
            </p>
          </div>

          <div className="border-t border-gray-200 pt-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Enrollment Details</h2>
            <div className="space-y-4">
              <div>
                <span className="block text-sm font-medium text-gray-700">Name</span>
                <span className="block mt-1 text-gray-900">{formData.name}</span>
              </div>
              <div>
                <span className="block text-sm font-medium text-gray-700">Email</span>
                <span className="block mt-1 text-gray-900">{formData.email}</span>
              </div>
              <div>
                <span className="block text-sm font-medium text-gray-700">Phone</span>
                <span className="block mt-1 text-gray-900">{formData.phone}</span>
              </div>
              <div>
                <span className="block text-sm font-medium text-gray-700">Course</span>
                <span className="block mt-1 text-gray-900">
                  {formData.courseId}
                </span>
              </div>
              <div>
                <span className="block text-sm font-medium text-gray-700">Batch Time</span>
                <span className="block mt-1 text-gray-900">{formData.batchTime}</span>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-8 mt-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Next Steps</h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <Calendar className="h-5 w-5 text-indigo-600 mt-1 mr-3" />
                <div>
                  <h3 className="font-medium text-gray-900">Orientation Session</h3>
                  <p className="text-gray-600">Join us for the orientation session to meet your instructors and classmates.</p>
                </div>
              </div>
              <div className="flex items-start">
                <Clock className="h-5 w-5 text-indigo-600 mt-1 mr-3" />
                <div>
                  <h3 className="font-medium text-gray-900">Course Materials</h3>
                  <p className="text-gray-600">Access to course materials will be provided within 24 hours.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-center">
            <Link
              to="/courses"
              className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              View Course Details
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}