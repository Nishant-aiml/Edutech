import { Link } from 'react-router-dom';
import { GraduationCap, Book, Users, Calendar, MessageSquare, Star } from 'lucide-react';
import Hero from '../components/Hero';
import TestimonialCard from '../components/TestimonialCard';
import EventCard from '../components/EventCard';
import type { Testimonial } from '../types';

const FEATURES = [
  {
    icon: Book,
    title: 'Expert-Led Courses',
    description: 'Learn from industry professionals with years of experience'
  },
  {
    icon: Users,
    title: 'Collaborative Learning',
    description: 'Join a community of passionate learners'
  },
  {
    icon: GraduationCap,
    title: 'Recognized Certification',
    description: 'Get certified and boost your career prospects'
  }
];

const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
    course: 'Web Development',
    content: 'The course structure and teaching methodology were excellent. I learned so much in such a short time.',
    rating: 5,
    date: '2024-03-15'
  },
  {
    id: '2',
    name: 'Michael Chen',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d',
    course: 'Data Science',
    content: 'The practical approach to learning helped me transition into a new career successfully.',
    rating: 5,
    date: '2024-03-10'
  }
];

const UPCOMING_EVENTS = [
  {
    id: '1',
    title: 'Tech Career Fair',
    date: '2024-04-15',
    time: '10:00 AM',
    location: 'Main Campus',
    description: 'Connect with top tech companies and explore career opportunities.'
  },
  {
    id: '2',
    title: 'Web Development Workshop',
    date: '2024-04-20',
    time: '2:00 PM',
    location: 'Online',
    description: 'Learn modern web development techniques from industry experts.'
  }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Hero />
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Us?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Transform your future with our comprehensive learning programs
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {FEATURES.map((feature, index) => (
              <div key={index} className="p-6 bg-gray-50 rounded-xl">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Student Testimonials</h2>
            <p className="mt-4 text-lg text-gray-600">
              Hear what our students have to say about their learning experience
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {TESTIMONIALS.map((testimonial) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Link
              to="/testimonials"
              className="inline-flex items-center text-indigo-600 hover:text-indigo-700"
            >
              <span className="mr-2">View all testimonials</span>
              <Star className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Upcoming Events Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Upcoming Events</h2>
            <p className="mt-4 text-lg text-gray-600">
              Join our events and enhance your learning experience
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {UPCOMING_EVENTS.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Link
              to="/events"
              className="inline-flex items-center text-indigo-600 hover:text-indigo-700"
            >
              <span className="mr-2">View all events</span>
              <Calendar className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Have Questions?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Get in touch with us for any queries about our courses
            </p>
          </div>
          
          <div className="text-center">
            <Link
              to="/contact"
              className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <MessageSquare className="h-5 w-5 mr-2" />
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}