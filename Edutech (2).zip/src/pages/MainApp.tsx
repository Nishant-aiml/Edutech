import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Features from '../components/Features';
import Stats from '../components/Stats';
import PopularCourses from '../components/PopularCourses';
import Pricing from '../components/Pricing';

export default function MainApp() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="pt-16">
        <Hero />
        <Features />
        <Stats />
        <PopularCourses />
        <Pricing />
      </main>
    </div>
  );
}