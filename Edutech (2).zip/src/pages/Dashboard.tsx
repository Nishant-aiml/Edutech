import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  BookOpen,
  Video,
  Users,
  BarChart2,
  MessageSquare,
  Award,
  Download,
  Upload,
  Settings
} from 'lucide-react';
import StudentDashboard from '../components/dashboard/StudentDashboard';
import EducatorDashboard from '../components/dashboard/EducatorDashboard';

const MENU_ITEMS = {
  student: [
    { icon: BookOpen, label: 'My Courses', href: '/dashboard/courses' },
    { icon: Video, label: 'Live Classes', href: '/dashboard/live' },
    { icon: Users, label: 'My Mentors', href: '/dashboard/mentors' },
    { icon: Award, label: 'Achievements', href: '/dashboard/achievements' },
    { icon: Download, label: 'Downloads', href: '/dashboard/downloads' },
    { icon: Settings, label: 'Settings', href: '/dashboard/settings' }
  ],
  educator: [
    { icon: Video, label: 'My Classes', href: '/dashboard/classes' },
    { icon: Upload, label: 'Upload Content', href: '/dashboard/upload' },
    { icon: Users, label: 'My Students', href: '/dashboard/students' },
    { icon: BarChart2, label: 'Analytics', href: '/dashboard/analytics' },
    { icon: MessageSquare, label: 'Messages', href: '/dashboard/messages' },
    { icon: Settings, label: 'Settings', href: '/dashboard/settings' }
  ]
};

export default function Dashboard() {
  const { user, isEducator } = useAuth();
  const [activeMenu, setActiveMenu] = useState('overview');

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Please log in to access the dashboard.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white h-screen fixed shadow-sm">
          <div className="p-6">
            <div className="flex items-center space-x-4">
              <img
                src={user.avatar}
                alt={user.name}
                className="h-12 w-12 rounded-full"
              />
              <div>
                <h2 className="font-semibold text-gray-900">{user.name}</h2>
                <p className="text-sm text-gray-600 capitalize">{user.role}</p>
              </div>
            </div>
          </div>

          <nav className="mt-6">
            {(isEducator ? MENU_ITEMS.educator : MENU_ITEMS.student).map((item, index) => (
              <button
                key={index}
                onClick={() => setActiveMenu(item.label.toLowerCase())}
                className={`w-full flex items-center space-x-2 px-6 py-3 text-gray-600 hover:bg-gray-50 hover:text-indigo-600 ${
                  activeMenu === item.label.toLowerCase()
                    ? 'bg-indigo-50 text-indigo-600 border-r-4 border-indigo-600'
                    : ''
                }`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 ml-64">
          <div className="p-8">
            {isEducator ? (
              <EducatorDashboard activeMenu={activeMenu} />
            ) : (
              <StudentDashboard activeMenu={activeMenu} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}