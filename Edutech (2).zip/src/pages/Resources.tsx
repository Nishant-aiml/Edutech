import { BookOpen, FileText, Video, Download, ExternalLink, Clock } from 'lucide-react';

const RESOURCES = [
  {
    category: 'Study Materials',
    icon: BookOpen,
    items: [
      {
        title: 'Web Development Guide',
        description: 'Comprehensive guide covering HTML, CSS, and JavaScript fundamentals',
        type: 'PDF',
        size: '2.5 MB'
      },
      {
        title: 'Data Structures Handbook',
        description: 'Essential data structures and algorithms explained',
        type: 'PDF',
        size: '3.1 MB'
      }
    ]
  },
  {
    category: 'Practice Tests',
    icon: FileText,
    items: [
      {
        title: 'JavaScript Assessment',
        description: 'Test your JavaScript knowledge with 50 practice questions',
        type: 'Quiz',
        duration: '60 mins'
      },
      {
        title: 'React Proficiency Test',
        description: 'Evaluate your React skills with real-world scenarios',
        type: 'Quiz',
        duration: '90 mins'
      }
    ]
  },
  {
    category: 'Video Tutorials',
    icon: Video,
    items: [
      {
        title: 'Git & GitHub Basics',
        description: 'Learn version control fundamentals with Git and GitHub',
        duration: '45 mins',
        level: 'Beginner'
      },
      {
        title: 'Database Design',
        description: 'Master database design principles and best practices',
        duration: '60 mins',
        level: 'Intermediate'
      }
    ]
  }
];

export default function Resources() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-3xl font-bold mb-4">Learning Resources</h1>
          <p className="text-xl opacity-90">
            Access comprehensive study materials, practice tests, and tutorials
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 gap-8">
          {RESOURCES.map((category, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center">
                  <div className="bg-indigo-100 p-3 rounded-lg mr-4">
                    <category.icon className="h-6 w-6 text-indigo-600" />
                  </div>
                  <h2 className="text-xl font-bold text-gray-900">{category.category}</h2>
                </div>
              </div>

              <div className="divide-y divide-gray-200">
                {category.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900 mb-1">
                          {item.title}
                        </h3>
                        <p className="text-gray-600 mb-2">{item.description}</p>
                        <div className="flex items-center text-sm text-gray-500">
                          {'type' in item && (
                            <span className="flex items-center">
                              <FileText className="h-4 w-4 mr-1" />
                              {item.type}
                              {item.size && <span className="ml-1">• {item.size}</span>}
                            </span>
                          )}
                          {'duration' in item && (
                            <span className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              {item.duration}
                              {item.level && <span className="ml-1">• {item.level}</span>}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="ml-4">
                        {'type' in item && item.type === 'PDF' ? (
                          <button className="flex items-center text-indigo-600 hover:text-indigo-700">
                            <Download className="h-5 w-5 mr-1" />
                            Download
                          </button>
                        ) : (
                          <button className="flex items-center text-indigo-600 hover:text-indigo-700">
                            <ExternalLink className="h-5 w-5 mr-1" />
                            Access
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}