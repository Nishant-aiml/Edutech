import { useState } from 'react';
import type { Course } from '../types';
import CourseSearch from '../components/CourseSearch';
import CourseFilters from '../components/CourseFilters';
import CourseGrid from '../components/CourseGrid';

const COURSES: Course[] = [
  {
    id: '1',
    title: 'Complete Web Development Bootcamp',
    description: 'Master HTML, CSS, JavaScript, React, and Node.js in this comprehensive course.',
    instructor: 'Sarah Johnson',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
    category: 'Development',
    level: 'Beginner',
    duration: '40 hours',
    rating: 4.8,
    enrolled: 15420
  },
  {
    id: '2',
    title: 'Data Science Fundamentals',
    description: 'Learn Python, statistics, and machine learning fundamentals.',
    instructor: 'Alex Thompson',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
    category: 'Data Science',
    level: 'Intermediate',
    duration: '35 hours',
    rating: 4.9,
    enrolled: 12340
  },
  {
    id: '3',
    title: 'UI/UX Design Masterclass',
    description: 'Create stunning user interfaces and improve user experience.',
    instructor: 'Emma Davis',
    thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5',
    category: 'Design',
    level: 'Beginner',
    duration: '28 hours',
    rating: 4.7,
    enrolled: 8960
  },
  {
    id: '4',
    title: 'Digital Marketing Strategy',
    description: 'Master SEO, social media, and content marketing strategies.',
    instructor: 'Michael Chen',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
    category: 'Marketing',
    level: 'Advanced',
    duration: '25 hours',
    rating: 4.6,
    enrolled: 6780
  }
];

export default function Courses() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All Levels');
  const [selectedDuration, setSelectedDuration] = useState('All Durations');
  const [showFilters, setShowFilters] = useState(false);

  const filteredCourses = COURSES.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    const matchesLevel = selectedLevel === 'All Levels' || course.level === selectedLevel;
    
    let matchesDuration = true;
    if (selectedDuration !== 'All Durations') {
      const hours = parseInt(course.duration);
      if (selectedDuration === '0-5 hours') matchesDuration = hours <= 5;
      else if (selectedDuration === '5-10 hours') matchesDuration = hours > 5 && hours <= 10;
      else if (selectedDuration === '10+ hours') matchesDuration = hours > 10;
    }

    return matchesSearch && matchesCategory && matchesLevel && matchesDuration;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-3xl font-bold mb-4">Explore Our Courses</h1>
          <p className="text-xl opacity-90">
            Discover courses taught by industry experts and enhance your skills
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div className="flex-1">
            <CourseSearch searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
          </div>
          <CourseFilters
            selectedCategory={selectedCategory}
            selectedLevel={selectedLevel}
            selectedDuration={selectedDuration}
            showFilters={showFilters}
            setShowFilters={setShowFilters}
            setSelectedCategory={setSelectedCategory}
            setSelectedLevel={setSelectedLevel}
            setSelectedDuration={setSelectedDuration}
          />
        </div>

        <CourseGrid courses={filteredCourses} />
      </div>
    </div>
  );
}