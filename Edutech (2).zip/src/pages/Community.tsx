import { useState } from 'react';
import { MessageSquare, Users, Search, ThumbsUp, MessageCircle, Share2 } from 'lucide-react';

const CATEGORIES = ['All', 'General Discussion', 'Course Help', 'Career Advice', 'Project Showcase'];

const SAMPLE_POSTS = [
  {
    id: '1',
    author: {
      name: 'Alex Chen',
      avatar: 'https://ui-avatars.com/api/?name=Alex+Chen&background=random'
    },
    category: 'Course Help',
    title: 'Need help with React Hooks',
    content: 'I\'m struggling with useEffect dependencies. Can someone explain when to include them?',
    likes: 24,
    comments: 12,
    timestamp: '2 hours ago'
  },
  {
    id: '2',
    author: {
      name: 'Sarah Johnson',
      avatar: 'https://ui-avatars.com/api/?name=Sarah+Johnson&background=random'
    },
    category: 'Project Showcase',
    title: 'Built my first full-stack app!',
    content: 'Just completed my first MERN stack project. Would love some feedback!',
    likes: 45,
    comments: 18,
    timestamp: '4 hours ago'
  }
];

export default function Community() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPosts = SAMPLE_POSTS.filter(post => {
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Community</h1>
              <p className="text-gray-600">Connect, share, and learn with fellow students</p>
            </div>
            <button className="btn">
              <MessageSquare className="h-5 w-5 mr-2" />
              Create New Post
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Categories</h2>
              <nav className="space-y-2">
                {CATEGORIES.map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium ${
                      selectedCategory === category
                        ? 'bg-indigo-50 text-indigo-600'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="mb-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search discussions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div className="space-y-4">
              {filteredPosts.map(post => (
                <div key={post.id} className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center mb-4">
                    <img
                      src={post.author.avatar}
                      alt={post.author.name}
                      className="h-10 w-10 rounded-full mr-3"
                    />
                    <div>
                      <h3 className="font-medium text-gray-900">{post.author.name}</h3>
                      <div className="flex items-center text-sm text-gray-500">
                        <span>{post.timestamp}</span>
                        <span className="mx-2">•</span>
                        <span className="text-indigo-600">{post.category}</span>
                      </div>
                    </div>
                  </div>

                  <h2 className="text-xl font-semibold text-gray-900 mb-2">{post.title}</h2>
                  <p className="text-gray-600 mb-4">{post.content}</p>

                  <div className="flex items-center space-x-4 text-gray-500">
                    <button className="flex items-center hover:text-indigo-600">
                      <ThumbsUp className="h-5 w-5 mr-1" />
                      {post.likes}
                    </button>
                    <button className="flex items-center hover:text-indigo-600">
                      <MessageCircle className="h-5 w-5 mr-1" />
                      {post.comments}
                    </button>
                    <button className="flex items-center hover:text-indigo-600">
                      <Share2 className="h-5 w-5 mr-1" />
                      Share
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}