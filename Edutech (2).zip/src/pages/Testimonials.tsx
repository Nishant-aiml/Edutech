import { useState } from 'react';
import { Star } from 'lucide-react';
import type { Testimonial } from '../types';
import TestimonialList from '../components/TestimonialList';
import TestimonialFilters from '../components/TestimonialFilters';

const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
    course: 'Web Development',
    rating: 5,
    content: 'The course structure and teaching methodology were excellent. I learned so much in such a short time and was able to build real-world projects that helped me land my dream job.',
    date: '2024-03-15',
    position: 'Frontend Developer',
    company: 'Tech Corp'
  },
  {
    id: '2',
    name: 'Michael Chen',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d',
    course: 'Data Science',
    rating: 5,
    content: 'The practical approach to learning helped me transition into a new career successfully. The instructors were very supportive and the course material was up-to-date with industry standards.',
    date: '2024-03-10',
    position: 'Data Analyst',
    company: 'Analytics Inc'
  },
  {
    id: '3',
    name: 'Emma Davis',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80',
    course: 'UI/UX Design',
    rating: 4,
    content: 'Great course for anyone looking to get into UI/UX design. The projects were challenging but rewarding, and the feedback from instructors was invaluable.',
    date: '2024-03-05',
    position: 'UX Designer',
    company: 'Design Studio'
  },
  {
    id: '4',
    name: 'Alex Thompson',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
    course: 'Digital Marketing',
    rating: 5,
    content: 'This course transformed my understanding of digital marketing. The hands-on experience with real campaigns was particularly valuable.',
    date: '2024-03-01',
    position: 'Marketing Manager',
    company: 'Growth Marketing'
  }
];

export default function Testimonials() {
  const [selectedCourse, setSelectedCourse] = useState('All Courses');
  const [selectedRating, setSelectedRating] = useState<number | null>(null);

  const filteredTestimonials = TESTIMONIALS.filter(testimonial => {
    const matchesCourse = selectedCourse === 'All Courses' || testimonial.course === selectedCourse;
    const matchesRating = !selectedRating || testimonial.rating >= selectedRating;
    return matchesCourse && matchesRating;
  });

  const averageRating = TESTIMONIALS.reduce((acc, curr) => acc + curr.rating, 0) / TESTIMONIALS.length;

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Student Success Stories</h1>
            <p className="text-xl opacity-90 mb-8">
              Hear what our students have to say about their learning experience
            </p>
            <div className="flex items-center justify-center gap-2">
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-6 w-6 ${
                      star <= averageRating
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-lg font-semibold">
                {averageRating.toFixed(1)} average rating
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <TestimonialFilters
          selectedCourse={selectedCourse}
          setSelectedCourse={setSelectedCourse}
          selectedRating={selectedRating}
          setSelectedRating={setSelectedRating}
        />

        <TestimonialList testimonials={filteredTestimonials} />

        {filteredTestimonials.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600">No testimonials found matching your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}