import { useState } from 'react';
import EventCard from '../components/EventCard';

const EVENTS = [
  {
    id: '1',
    title: 'Tech Career Fair',
    date: '2024-04-15',
    time: '10:00 AM',
    location: 'Main Campus',
    description: 'Connect with top tech companies and explore career opportunities.'
  },
  {
    id: '2',
    title: 'Web Development Workshop',
    date: '2024-04-20',
    time: '2:00 PM',
    location: 'Online',
    description: 'Learn modern web development techniques from industry experts.'
  }
];

export default function Events() {
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-3xl font-bold mb-4">Upcoming Events</h1>
          <p className="text-xl opacity-90">
            Join our events and enhance your learning experience
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {EVENTS.map(event => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      </div>
    </div>
  );
}