import { createHash, randomBytes } from 'crypto';
import {
  createUser,
  getUserByEmail,
  createSession,
  getSessionByToken,
  deleteSession
} from './database';

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: string;
  avatar?: string;
  language?: string;
  subscription_tier?: string;
}

function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

function generateToken(): string {
  return randomBytes(32).toString('hex');
}

export async function register(credentials: {
  name: string;
  email: string;
  password: string;
  role: string;
  language?: string;
}) {
  const existingUser = await getUserByEmail(credentials.email);
  if (existingUser) {
    throw new Error('Email already registered');
  }

  const userId = await createUser({
    name: credentials.name,
    email: credentials.email,
    password_hash: hashPassword(credentials.password),
    role: credentials.role,
    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(credentials.name)}&background=random`,
    language: credentials.language,
    subscription_tier: 'free'
  });

  const token = generateToken();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 30); // 30 days from now

  await createSession(Number(userId), token, expiresAt);

  const user = await getUserByEmail(credentials.email);
  return { token, user };
}

export async function login(credentials: { email: string; password: string }) {
  const user = await getUserByEmail(credentials.email);
  if (!user || user.password_hash !== hashPassword(credentials.password)) {
    throw new Error('Invalid email or password');
  }

  const token = generateToken();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 30); // 30 days from now

  await createSession(user.id, token, expiresAt);

  return { token, user };
}

export async function validateSession(token: string) {
  return getSessionByToken(token);
}

export async function logout(token: string) {
  await deleteSession(token);
}