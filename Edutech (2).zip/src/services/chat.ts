import db from '../db/init';
import { format } from 'date-fns';

export interface Message {
  id: number;
  content: string;
  sender_id: number;
  sender_name: string;
  sender_avatar: string;
  created_at: string;
  read_at: string | null;
}

export interface ChatRoom {
  id: number;
  student_id: number;
  educator_id: number;
  student_name: string;
  educator_name: string;
  last_message?: Message;
}

export function createChatRoom(studentId: number, educatorId: number): ChatRoom {
  try {
    return db.prepare(`
      INSERT INTO chat_rooms (student_id, educator_id)
      VALUES (?, ?)
      RETURNING *
    `).get(studentId, educatorId) as ChatRoom;
  } catch (error) {
    if ((error as any).code === 'SQLITE_CONSTRAINT') {
      return db.prepare(
        'SELECT * FROM chat_rooms WHERE student_id = ? AND educator_id = ?'
      ).get(studentId, educatorId) as ChatRoom;
    }
    throw error;
  }
}

export function getChatRooms(userId: number): ChatRoom[] {
  return db.prepare(`
    SELECT 
      cr.*,
      s.name as student_name,
      e.name as educator_name,
      (
        SELECT json_object(
          'id', m.id,
          'content', m.content,
          'sender_id', m.sender_id,
          'sender_name', u.name,
          'sender_avatar', u.avatar,
          'created_at', m.created_at,
          'read_at', m.read_at
        )
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.chat_room_id = cr.id
        ORDER BY m.created_at DESC
        LIMIT 1
      ) as last_message
    FROM chat_rooms cr
    JOIN users s ON cr.student_id = s.id
    JOIN users e ON cr.educator_id = e.id
    WHERE cr.student_id = ? OR cr.educator_id = ?
    ORDER BY cr.created_at DESC
  `).all(userId, userId) as ChatRoom[];
}

export function getMessages(chatRoomId: number, userId: number): Message[] {
  // Mark messages as read
  db.prepare(`
    UPDATE messages
    SET read_at = CURRENT_TIMESTAMP
    WHERE chat_room_id = ? AND sender_id != ? AND read_at IS NULL
  `).run(chatRoomId, userId);

  return db.prepare(`
    SELECT 
      m.*,
      u.name as sender_name,
      u.avatar as sender_avatar
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.chat_room_id = ?
    ORDER BY m.created_at ASC
  `).all(chatRoomId) as Message[];
}

export function sendMessage(chatRoomId: number, senderId: number, content: string): Message {
  return db.prepare(`
    INSERT INTO messages (chat_room_id, sender_id, content)
    VALUES (?, ?, ?)
    RETURNING *
  `).get(chatRoomId, senderId, content) as Message;
}

export function getUnreadCount(userId: number): number {
  return db.prepare(`
    SELECT COUNT(*) as count
    FROM messages m
    JOIN chat_rooms cr ON m.chat_room_id = cr.id
    WHERE (cr.student_id = ? OR cr.educator_id = ?)
    AND m.sender_id != ?
    AND m.read_at IS NULL
  `).get(userId, userId, userId).count;
}