import { createClient } from '@libsql/client';

const db = createClient({
  url: 'file:local.db',
});

export async function initializeDatabase() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      avatar TEXT,
      language TEXT,
      subscription_tier TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS chats (
      id INTEGER PRIMARY KEY,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      message TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sender_id) REFERENCES users (id),
      FOREIGN KEY (receiver_id) REFERENCES users (id)
    )
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL,
      token TEXT UNIQUE NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `);
}

export async function createUser(user: {
  name: string;
  email: string;
  password_hash: string;
  role: string;
  avatar?: string;
  language?: string;
  subscription_tier?: string;
}) {
  const result = await db.execute({
    sql: `
      INSERT INTO users (name, email, password_hash, role, avatar, language, subscription_tier)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
    args: [
      user.name,
      user.email,
      user.password_hash,
      user.role,
      user.avatar,
      user.language,
      user.subscription_tier
    ]
  });
  return result.lastInsertRowid;
}

export async function getUserByEmail(email: string) {
  const result = await db.execute({
    sql: 'SELECT * FROM users WHERE email = ?',
    args: [email]
  });
  return result.rows[0];
}

export async function createSession(userId: number, token: string, expiresAt: Date) {
  await db.execute({
    sql: `
      INSERT INTO sessions (user_id, token, expires_at)
      VALUES (?, ?, ?)
    `,
    args: [userId, token, expiresAt.toISOString()]
  });
}

export async function getSessionByToken(token: string) {
  const result = await db.execute({
    sql: `
      SELECT s.*, u.*
      FROM sessions s
      JOIN users u ON s.user_id = u.id
      WHERE s.token = ? AND s.expires_at > CURRENT_TIMESTAMP
    `,
    args: [token]
  });
  return result.rows[0];
}

export async function deleteSession(token: string) {
  await db.execute({
    sql: 'DELETE FROM sessions WHERE token = ?',
    args: [token]
  });
}

export async function createChat(senderId: number, receiverId: number, message: string) {
  const result = await db.execute({
    sql: `
      INSERT INTO chats (sender_id, receiver_id, message)
      VALUES (?, ?, ?)
    `,
    args: [senderId, receiverId, message]
  });
  return result.lastInsertRowid;
}

export async function getChatMessages(userId1: number, userId2: number) {
  const result = await db.execute({
    sql: `
      SELECT c.*, u.name as sender_name, u.avatar as sender_avatar
      FROM chats c
      JOIN users u ON c.sender_id = u.id
      WHERE (c.sender_id = ? AND c.receiver_id = ?)
         OR (c.sender_id = ? AND c.receiver_id = ?)
      ORDER BY c.created_at ASC
    `,
    args: [userId1, userId2, userId2, userId1]
  });
  return result.rows;
}

export default db;